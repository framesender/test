﻿
CREATE TABLE `t_record` (
  `id` INTEGER(11) NOT NULL AUTO_INCREMENT,
  `sort` INTEGER(11) DEFAULT NULL,
  `name` VARCHAR(200) COLLATE utf8_general_ci DEFAULT NULL,
  `img` VARCHAR(255) COLLATE utf8_general_ci DEFAULT NULL,
  `link` TEXT COLLATE utf8_general_ci,
  `type` TINYINT(1) NOT NULL DEFAULT '1',
  `lft` TINYINT(4) DEFAULT NULL,
  PRIMARY KEY (`id`)

)ENGINE=MyISAM
AUTO_INCREMENT=63


INSERT INTO `t_record` (`id`, `sort`, `name`, `img`, `link`, `type`, `lft`) VALUES
  (32,1,'Каватина Нормы из оперы \\\"Норма\\\" ^В.Беллини.',NULL,'song_1.mp3',2,NULL),
  (33,2,'Сцена письма Татьяны из оперы \"Евгений Онегин\" ^Чайковский',NULL,'song_33.mp3',2,NULL),
  (35,3,'Романс \"Забыть так скоро\"^Чайковский',NULL,'song_34.mp3',2,NULL),
  (36,5,'Романс \"То было раннею весной\" ^Чайковский',NULL,'song_36.mp3',2,NULL),
  (37,6,'Романс \"Не пой, красавица, при мне\" ^Рахманов',NULL,'song_37.mp3',2,NULL),
  (39,7,'Романс \"Сирень\" ^Рахманинов',NULL,'song_38.mp3',2,NULL),
  (40,14,'Романс \"Маргаритки\" ^Рахманинов',NULL,'song_40.mp3',2,NULL),
  (41,16,'Волшебная флейта. Ария Памины из II действия ^Моцарт',NULL,'song_41.mp3',2,NULL),
  (42,19,'Русалка. Ария Русалки из I действия ^Дворжак',NULL,'song_42.mp3',2,NULL),
  (62,100,'название с \"кавычками\"^аффтар в \"кавычках\"','vd1.jpg','<object width=\"306\" height=\"255\"><param name=\"movie\" value=\"http://www.youtube.com/v/HJ0i-89OfhE&hl=en_US&fs=1&\"></param><param name=\"allowFullScreen\" value=\"true\"></param><param name=\"allowscriptaccess\" value=\"always\"></param><embed src=\"http://www.youtube.com/v/HJ0i-89OfhE&hl=en_US&fs=1&\" type=\"application/x-shockwave-flash\" allowscriptaccess=\"always\" allowfullscreen=\"true\" width=\"306\" height=\"255\"></embed></object>',1,0);
COMMIT;


INSERT INTO `list_mod` (`title_list_mod`, `pic_list_mod`, `src_list_mod`, `cdat_mod`, `mm_id`, `list_mod_rules`) VALUES  
  ('Записи','tv.jpg','records',0,NULL,'1;2');
COMMIT;
