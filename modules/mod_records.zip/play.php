<?php
    include_once "core/cl_db.php";
    $rec = new cl_db();
    echo '
        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            
             <script type="text/javascript" src="js/audio-player.js"></script>  
             <script type="text/javascript">  
                 AudioPlayer.setup("pl.swf", {  
                     width: 295,  
                     initialvolume: 100,  
                     transparentpagebg: "yes",  
                     left: "000000",
                     autostart: "yes",  
                     lefticon: "FFFFFF"  
                 });  
             </script> 
            
            <body bgcolor="#EEE5DC">
    ';
    
    $song = "/files/media/".$_GET['song'];
    $art = htmlspecialchars($rec->getdriver()->Strip($_GET['artist']));
    $title = htmlspecialchars($rec->getdriver()->Strip($_GET['title']));
  
    echo '
        <div style="width:300px" align="center">

        <div style="background:#EEE5DC; width:295px;" align="center"><img src="images/dinara_290.jpg"></div>
        
         <p id="audioplayer_1">Alternative content</p>  
            <script type="text/javascript">  
                 AudioPlayer.embed("audioplayer_1", {soundFile: "'.$song.'",
                                                     artists: "'.$art.'",
                                                     titles: "'.$title.'"
                 });  
            </script>  
        
        </div>
        
</body>
</html>

        ';
        
?>